package com.sunmi.msrtests.utilities;

public class Constants {
    public static final String  KeyTestCaseExecutionStatus = "TestExecutionStatusObject";
    public static final String  KeyTestCaseNumber = "TestcaseNumaberKey";
    public static final String TagTestcaseExecution = "TestcaseExecutionSchedulerTag";
    public static final long   TestcaseRetryIntervalInMinutes = 15;
}