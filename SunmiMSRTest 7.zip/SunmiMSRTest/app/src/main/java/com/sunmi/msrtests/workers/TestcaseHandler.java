package com.sunmi.msrtests.workers;

import com.sunmi.msrtests.data.entity.FDRCTestCase;
import com.sunmi.msrtests.data.entity.TestCaseStatus;

public interface TestcaseHandler {
    TestCaseStatus executeTestcase();
}

