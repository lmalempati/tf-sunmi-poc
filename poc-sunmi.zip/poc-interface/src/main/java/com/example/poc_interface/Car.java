package com.example.poc_interface;

public interface Car {
    boolean start();
    boolean stop();
}