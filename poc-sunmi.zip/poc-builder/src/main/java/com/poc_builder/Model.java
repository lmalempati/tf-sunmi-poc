package com.poc_builder;

public enum Model {
    SUV,
    CompactSUV,
    Hatchback,
    Sedan
}
