package com.example.helloworld;


import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import Test.Book;
import Test.BookMain;

public class MainActivity extends AppCompatActivity {

    public static final String EXTRA_MESSAGE = "com.example.helloworld.MESSAGE";

    private Button btSend;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
//        System.setProperty("java.awt.headless", "true");

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btSend = findViewById(R.id.btSend);
        btSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendMessage();
            }
        });
    }

    public void sendMessage(){
//         comes from external library / jar
        BookMain.jaxbSample();
//        BookMain.XmlEncoderSample();
//        BookMain.JacksonSample();
//        BookMain.Xstream();
//        SimpleSerializer.toXml();



//        Toast.makeText(MainActivity.this,msg, Toast.LENGTH_LONG).show();
//        intent.putExtra(EXTRA_MESSAGE, message);
//        intent.putExtra(msg, msg);
//        startActivity(intent);
    }
}